<section
    id="countdown"
    class="countdown-section relative overflow-hidden bg-[#eeeeec] px-6 py-24 sm:py-28"
>

    {{-- =========================================
         BACKGROUND DECORATION
    ========================================== --}}

    <div
        class="countdown-orb-one absolute -left-32 top-10 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="countdown-orb-two absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    {{-- =========================================
         CONTENT
    ========================================== --}}

    <div
        class="relative z-10 mx-auto max-w-3xl text-center"
    >

        {{-- Header --}}
        <div class="countdown-header">

            <p
                class="text-[10px] tracking-[0.45em] text-neutral-500"
            >
                COUNTDOWN TO OUR SPECIAL DAY
            </p>


            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span class="h-px w-10 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-300"></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Menuju Hari Bahagia
            </h2>

        </div>


        {{-- =========================================
             COUNTDOWN
        ========================================== --}}

        <div
            id="countdownTimer"
            class="mt-12 grid grid-cols-4 gap-2 sm:gap-5"
        >

            {{-- DAYS --}}
            <div
                class="countdown-box"
                style="--countdown-delay: .15s;"
            >

                <p
                    id="days"
                    class="countdown-number text-3xl font-light text-neutral-900 sm:text-5xl"
                >
                    00
                </p>

                <div class="mx-auto mt-3 h-px w-5 bg-neutral-300"></div>

                <p
                    class="mt-3 text-[8px] tracking-[0.25em] text-neutral-500 sm:text-[9px]"
                >
                    HARI
                </p>

            </div>


            {{-- HOURS --}}
            <div
                class="countdown-box"
                style="--countdown-delay: .3s;"
            >

                <p
                    id="hours"
                    class="countdown-number text-3xl font-light text-neutral-900 sm:text-5xl"
                >
                    00
                </p>

                <div class="mx-auto mt-3 h-px w-5 bg-neutral-300"></div>

                <p
                    class="mt-3 text-[8px] tracking-[0.25em] text-neutral-500 sm:text-[9px]"
                >
                    JAM
                </p>

            </div>


            {{-- MINUTES --}}
            <div
                class="countdown-box"
                style="--countdown-delay: .45s;"
            >

                <p
                    id="minutes"
                    class="countdown-number text-3xl font-light text-neutral-900 sm:text-5xl"
                >
                    00
                </p>

                <div class="mx-auto mt-3 h-px w-5 bg-neutral-300"></div>

                <p
                    class="mt-3 text-[8px] tracking-[0.25em] text-neutral-500 sm:text-[9px]"
                >
                    MENIT
                </p>

            </div>


            {{-- SECONDS --}}
            <div
                class="countdown-box"
                style="--countdown-delay: .6s;"
            >

                <p
                    id="seconds"
                    class="countdown-number text-3xl font-light text-neutral-900 sm:text-5xl"
                >
                    00
                </p>

                <div class="mx-auto mt-3 h-px w-5 bg-neutral-300"></div>

                <p
                    class="mt-3 text-[8px] tracking-[0.25em] text-neutral-500 sm:text-[9px]"
                >
                    DETIK
                </p>

            </div>

        </div>


        {{-- =========================================
             MESSAGE
        ========================================== --}}

        <div
            id="countdownMessage"
            class="countdown-message mt-10 hidden"
        >

            <div class="mx-auto flex items-center justify-center gap-3">

                <span class="h-px w-8 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ♡
                </span>

                <span class="h-px w-8 bg-neutral-300"></span>

            </div>

            <p class="mt-5 text-sm text-neutral-600">
                Hari bahagia kami telah tiba. 🤍
            </p>

        </div>


        {{-- Bottom ornament --}}
        <div class="mt-12">

            <span
                class="text-xl text-neutral-300"
            >
                ❦
            </span>

        </div>

    </div>

</section>


<style>

/* =========================================================
   BACKGROUND
========================================================= */

.countdown-section {
    isolation: isolate;
}

.countdown-orb-one {
    animation:
        countdownOrbOne 12s
        ease-in-out
        infinite
        alternate;
}

.countdown-orb-two {
    animation:
        countdownOrbTwo 14s
        ease-in-out
        infinite
        alternate;
}


@keyframes countdownOrbOne {

    from {
        transform:
            translate3d(0, 0, 0)
            scale(1);
    }

    to {
        transform:
            translate3d(35px, 25px, 0)
            scale(1.08);
    }

}


@keyframes countdownOrbTwo {

    from {
        transform:
            translate3d(0, 0, 0)
            scale(1);
    }

    to {
        transform:
            translate3d(-35px, -25px, 0)
            scale(1.08);
    }

}


/* =========================================================
   HEADER
========================================================= */

.countdown-header {

    animation:
        countdownHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        both;

}


@keyframes countdownHeaderIn {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}


/* =========================================================
   COUNTDOWN BOX
========================================================= */

.countdown-box {

    position: relative;

    border:
        1px solid rgba(212,212,212,.8);

    border-radius:
        1.25rem;

    background:
        rgba(255,255,255,.65);

    padding:
        1.25rem .5rem;

    box-shadow:
        0 5px 20px rgba(0,0,0,.025);

    backdrop-filter:
        blur(5px);

    opacity: 0;

    transform:
        translateY(30px)
        scale(.96);

    animation:
        countdownBoxIn
        1s
        cubic-bezier(.22,1,.36,1)
        var(--countdown-delay)
        forwards;

    transition:
        transform .5s ease,
        box-shadow .5s ease;

}


.countdown-box:hover {

    transform:
        translateY(-5px)
        scale(1.02);

    box-shadow:
        0 15px 30px rgba(0,0,0,.07);

}


@keyframes countdownBoxIn {

    from {

        opacity: 0;

        transform:
            translateY(30px)
            scale(.96);

    }

    to {

        opacity: 1;

        transform:
            translateY(0)
            scale(1);

    }

}


/* =========================================================
   NUMBER
========================================================= */

.countdown-number {

    font-variant-numeric:
        tabular-nums;

    transition:
        opacity .15s ease,
        transform .15s ease;

}


/* =========================================================
   NUMBER CHANGE ANIMATION
========================================================= */

.countdown-number.tick {

    animation:
        countdownTick
        .3s
        ease-out;

}


@keyframes countdownTick {

    0% {

        opacity: .35;

        transform:
            translateY(-4px);

    }

    100% {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MESSAGE
========================================================= */

.countdown-message {

    animation:
        countdownMessageIn
        1s
        ease-out
        both;

}


@keyframes countdownMessageIn {

    from {

        opacity: 0;

        transform:
            translateY(15px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .countdown-section {

        padding-top:
            5rem;

        padding-bottom:
            5rem;

    }

    .countdown-box {

        padding:
            1rem .25rem;

        border-radius:
            1rem;

    }

}


/* =========================================================
   REDUCE MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .countdown-orb-one,
    .countdown-orb-two,
    .countdown-header,
    .countdown-box,
    .countdown-message,
    .countdown-number {

        animation:
            none !important;

        transition:
            none !important;

    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    /*
    ========================================================
    TARGET DATE
    ========================================================
    */

    const targetDate =
        new Date(window.weddingDate).getTime();


    /*
    ========================================================
    ELEMENTS
    ========================================================
    */

    const daysElement =
        document.getElementById('days');

    const hoursElement =
        document.getElementById('hours');

    const minutesElement =
        document.getElementById('minutes');

    const secondsElement =
        document.getElementById('seconds');

    const messageElement =
        document.getElementById('countdownMessage');


    if (
        !daysElement ||
        !hoursElement ||
        !minutesElement ||
        !secondsElement
    ) {
        return;
    }


    /*
    ========================================================
    FORMAT NUMBER
    ========================================================
    */

    function pad(number) {

        return String(number).padStart(2, '0');

    }


    /*
    ========================================================
    UPDATE NUMBER
    ========================================================
    */

    function updateNumber(element, value) {

        const formatted =
            pad(value);

        if (element.textContent !== formatted) {

            element.classList.remove('tick');

            void element.offsetWidth;

            element.textContent =
                formatted;

            element.classList.add('tick');

        }

    }


    /*
    ========================================================
    COUNTDOWN
    ========================================================
    */

    function updateCountdown() {

        const now =
            new Date().getTime();

        const distance =
            targetDate - now;


        /*
        Wedding day reached
        */

        if (distance <= 0) {

            updateNumber(daysElement, 0);
            updateNumber(hoursElement, 0);
            updateNumber(minutesElement, 0);
            updateNumber(secondsElement, 0);


            if (messageElement) {

                messageElement.classList.remove('hidden');

            }

            clearInterval(countdownInterval);

            return;

        }


        /*
        Calculate time
        */

        const days =
            Math.floor(
                distance /
                (1000 * 60 * 60 * 24)
            );

        const hours =
            Math.floor(
                (distance %
                    (1000 * 60 * 60 * 24)
                ) /
                (1000 * 60 * 60)
            );

        const minutes =
            Math.floor(
                (distance %
                    (1000 * 60 * 60)
                ) /
                (1000 * 60)
            );

        const seconds =
            Math.floor(
                (distance %
                    (1000 * 60)
                ) /
                1000
            );


        /*
        Update UI
        */

        updateNumber(
            daysElement,
            days
        );

        updateNumber(
            hoursElement,
            hours
        );

        updateNumber(
            minutesElement,
            minutes
        );

        updateNumber(
            secondsElement,
            seconds
        );

    }


    /*
    ========================================================
    START
    ========================================================
    */

    updateCountdown();

    const countdownInterval =
        setInterval(
            updateCountdown,
            1000
        );

});

</script>


<script>
    window.weddingDate = @json(
        \Carbon\Carbon::parse($wedding->wedding_date)
            ->setTime(8, 0, 0)
            ->timezone('Asia/Jakarta')
            ->format('Y-m-d\TH:i:sP')
    );
</script>