<section
    id="couple"
    class="couple-section relative overflow-hidden bg-[#eeeeec] px-6 py-24 sm:py-28"
>

    {{-- Decorative background --}}
    <div
        class="couple-orb absolute -left-32 top-20 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="couple-orb-reverse absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    <div class="relative z-10 mx-auto max-w-4xl">


        {{-- =========================================
             TITLE
        ========================================== --}}

        <div class="couple-title mb-16 text-center sm:mb-20">

            <p class="text-[10px] tracking-[0.45em] text-neutral-500">
                THE COUPLE
            </p>

            <div class="mx-auto mt-5 flex items-center justify-center gap-3">

                <span class="h-px w-10 bg-neutral-400"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-400"></span>

            </div>

            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Mempelai
            </h2>

        </div>


        {{-- =========================================
             BRIDE
        ========================================== --}}

        <div
            class="couple-person bride-person mx-auto max-w-md text-center"
        >

            <div class="couple-photo-wrapper mx-auto mb-8 w-60 sm:w-64">

                <div
                    class="couple-photo relative overflow-hidden rounded-t-[130px] rounded-b-2xl border-8 border-white/70 bg-white shadow-xl"
                >

                    <img
                        src="{{ $wedding->bride_image
                            ? asset($wedding->bride_image)
                            : asset('images/wedding/couple/bride.jpg') }}"
                        alt="{{ $wedding->bride_name }}"
                        class="couple-photo-image h-[340px] w-full object-cover grayscale sm:h-[360px]"
                    >

                </div>

            </div>


            <p class="mb-3 text-[9px] tracking-[0.35em] text-neutral-400">
                THE BRIDE
            </p>

            <h3
                class="text-4xl font-light tracking-wide text-neutral-900 sm:text-5xl"
            >
                {{ $wedding->bride_name }}
            </h3>

            <div class="mx-auto mt-5 h-px w-10 bg-neutral-400"></div>

            <p class="mt-5 text-sm leading-7 text-neutral-600">
                Putri dari<br>

                <span class="font-medium text-neutral-800">
                    {{ $wedding->bride_parents }}
                </span>
            </p>

        </div>


        {{-- =========================================
             AMPERSAND
        ========================================== --}}

        <div
            class="couple-ampersand my-16 flex items-center justify-center sm:my-20"
        >

            <div class="h-px w-14 bg-neutral-300 sm:w-16"></div>

            <span
                class="mx-5 font-serif text-4xl font-light text-neutral-400"
            >
                &
            </span>

            <div class="h-px w-14 bg-neutral-300 sm:w-16"></div>

        </div>


        {{-- =========================================
             GROOM
        ========================================== --}}

        <div
            class="couple-person groom-person mx-auto max-w-md text-center"
        >

            <div class="couple-photo-wrapper mx-auto mb-8 w-60 sm:w-64">

                <div
                    class="couple-photo relative overflow-hidden rounded-t-[130px] rounded-b-2xl border-8 border-white/70 bg-white shadow-xl"
                >

                    <img
                        src="{{ $wedding->groom_image
                            ? asset($wedding->groom_image)
                            : asset('images/wedding/couple/groom.jpg') }}"
                        alt="{{ $wedding->groom_name }}"
                        class="couple-photo-image h-[340px] w-full object-cover grayscale sm:h-[360px]"
                    >

                </div>

            </div>


            <p class="mb-3 text-[9px] tracking-[0.35em] text-neutral-400">
                THE GROOM
            </p>

            <h3
                class="text-4xl font-light tracking-wide text-neutral-900 sm:text-5xl"
            >
                {{ $wedding->groom_name }}
            </h3>

            <div class="mx-auto mt-5 h-px w-10 bg-neutral-400"></div>

            <p class="mt-5 text-sm leading-7 text-neutral-600">
                Putra dari<br>

                <span class="font-medium text-neutral-800">
                    {{ $wedding->groom_parents }}
                </span>
            </p>

        </div>


        {{-- =========================================
             BOTTOM ORNAMENT
        ========================================== --}}

        <div
            class="couple-bottom-ornament mt-16 pb-12 text-center sm:mt-20 sm:pb-16"
        >

            <div class="mx-auto h-px w-12 bg-neutral-300"></div>

            <span class="mt-5 block text-2xl text-neutral-300">
                ❦
            </span>

        </div>

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.couple-section {
    isolation: isolate;

    /*
    Memberikan ruang aman agar konten terakhir
    tidak langsung berhenti di belakang navigation.
    */
    scroll-margin-top: 20px;
}


/* =========================================================
   BACKGROUND
========================================================= */

.couple-orb {

    animation:
        coupleOrbOne
        12s
        ease-in-out
        infinite
        alternate;

}


.couple-orb-reverse {

    animation:
        coupleOrbTwo
        14s
        ease-in-out
        infinite
        alternate;

}


@keyframes coupleOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(30px, 25px, 0)
            scale(1.08);

    }

}


@keyframes coupleOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-30px, -20px, 0)
            scale(1.08);

    }

}


/* =========================================================
   INITIAL STATE
========================================================= */

.couple-title,
.couple-person,
.couple-ampersand,
.couple-bottom-ornament {

    opacity:
        0;

    transform:
        translateY(35px);

}


/* =========================================================
   ACTIVE STATE
========================================================= */

.couple-section.is-visible .couple-title {

    animation:
        coupleReveal
        1s
        cubic-bezier(.22,1,.36,1)
        forwards;

}


.couple-section.is-visible .bride-person {

    animation:
        coupleReveal
        1.1s
        cubic-bezier(.22,1,.36,1)
        .15s
        forwards;

}


.couple-section.is-visible .couple-ampersand {

    animation:
        coupleReveal
        1s
        cubic-bezier(.22,1,.36,1)
        .35s
        forwards;

}


.couple-section.is-visible .groom-person {

    animation:
        coupleReveal
        1.1s
        cubic-bezier(.22,1,.36,1)
        .5s
        forwards;

}


.couple-section.is-visible .couple-bottom-ornament {

    animation:
        coupleReveal
        1s
        cubic-bezier(.22,1,.36,1)
        .8s
        forwards;

}


@keyframes coupleReveal {

    from {

        opacity:
            0;

        transform:
            translateY(35px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   PHOTO
========================================================= */

.couple-photo {

    transition:
        transform .7s ease,
        box-shadow .7s ease;

}


.couple-photo-image {

    transform:
        scale(1.02);

    transition:
        transform 1s ease,
        filter 1s ease;

}


.couple-photo:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 20px 40px rgba(0,0,0,.12);

}


.couple-photo:hover .couple-photo-image {

    transform:
        scale(1.08);

    filter:
        grayscale(.2);

}


/* =========================================================
   AMPERSAND
========================================================= */

.couple-section.is-visible .couple-ampersand span {

    animation:
        ampersandFloat
        4s
        ease-in-out
        1.5s
        infinite;

}


@keyframes ampersandFloat {

    0%,
    100% {

        transform:
            translateY(0);

    }

    50% {

        transform:
            translateY(-6px);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .couple-section {

        padding-top:
            5rem;

        padding-bottom:
            6rem;

    }


    .couple-photo-wrapper {

        width:
            15rem;

    }


    .couple-photo-image {

        height:
            340px;

    }


    .couple-ampersand {

        margin-top:
            4rem;

        margin-bottom:
            4rem;

    }


    .couple-bottom-ornament {

        padding-bottom:
            4rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .couple-orb,
    .couple-orb-reverse,
    .couple-title,
    .couple-person,
    .couple-ampersand,
    .couple-bottom-ornament,
    .couple-photo-image {

        animation:
            none !important;

        transition:
            none !important;

        opacity:
            1;

        transform:
            none;

    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const section =
        document.querySelector('#couple');


    if (!section) {
        return;
    }


    /*
    ========================================================
    COUPLE REVEAL
    ========================================================
    */

    const observer =
        new IntersectionObserver(
            function (entries) {

                entries.forEach(function (entry) {

                    if (entry.isIntersecting) {

                        section.classList.add(
                            'is-visible'
                        );

                        observer.unobserve(
                            section
                        );

                    }

                });

            },
            {
                threshold: 0.15
            }
        );


    observer.observe(section);

});

</script>