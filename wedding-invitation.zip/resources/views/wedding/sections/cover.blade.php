<section
    id="cover"
    class="cover-section relative flex min-h-screen items-center justify-center overflow-hidden bg-[#e9e9e7] px-6"
>

    {{-- =========================================
         BACKGROUND DECORATION
    ========================================== --}}
    <div class="pointer-events-none absolute inset-0 overflow-hidden">

        <div
            class="cover-orb absolute -left-32 -top-32 h-80 w-80 rounded-full bg-white/60 blur-3xl"
        ></div>

        <div
            class="cover-orb-reverse absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
        ></div>

    </div>


    {{-- =========================================
         MAIN CONTENT
    ========================================== --}}
    <div
        class="relative z-10 w-full max-w-md text-center"
    >

        {{-- Small title --}}
        <p
            class="cover-reveal text-[11px] font-medium tracking-[0.45em] text-neutral-600"
            style="--delay: .15s;"
        >
            THE WEDDING OF
        </p>


        {{-- =====================================
             PHOTO
        ====================================== --}}
        <div
            class="cover-photo-wrapper mx-auto mb-8 mt-8 w-[230px] sm:w-[260px]"
        >

            <div
                class="cover-photo relative overflow-hidden rounded-t-[120px] rounded-b-[20px] border-[8px] border-white/70 bg-white shadow-xl"
            >

                <img
                    src="{{ $wedding->cover_image
                        ? asset($wedding->cover_image)
                        : asset('images/wedding/cover.jpeg') }}"
                    alt="{{ $wedding->bride_name }} & {{ $wedding->groom_name }}"
                    class="cover-photo-image h-[320px] w-full object-cover grayscale"
                >

            </div>

        </div>


        {{-- =====================================
             NAMES
        ====================================== --}}
        <div class="text-neutral-900">

            <h1
                class="cover-name cover-reveal text-5xl font-light tracking-wide sm:text-6xl"
                style="--delay: .55s;"
            >
                {{ $wedding->bride_name }}
            </h1>


            <p
                class="cover-ampersand cover-reveal my-1 text-3xl font-light text-neutral-500"
                style="--delay: .75s;"
            >
                &
            </p>


            <h1
                class="cover-name cover-reveal text-5xl font-light tracking-wide sm:text-6xl"
                style="--delay: .9s;"
            >
                {{ $wedding->groom_name }}
            </h1>

        </div>


        {{-- =====================================
             DATE
        ====================================== --}}
        <div
            class="cover-date cover-reveal mt-7"
            style="--delay: 1.1s;"
        >

            <div
                class="mx-auto mb-5 h-px w-12 bg-neutral-500"
            ></div>

            <p
                class="text-xs tracking-[0.35em] text-neutral-700"
            >
                {{ $wedding->wedding_date->format('d-m-Y') }}
            </p>

        </div>


        {{-- =====================================
             BUTTON
        ====================================== --}}
        <div
            class="cover-button cover-reveal"
            style="--delay: 1.35s;"
        >

            <button
                id="coverButton"
                type="button"
                class="group relative mt-9 overflow-hidden rounded-full border border-neutral-700 bg-transparent px-8 py-3 text-[11px] font-medium tracking-[0.25em] text-neutral-800 transition-all duration-500 hover:scale-105 hover:bg-neutral-900 hover:text-white active:scale-95"
            >

                <span class="relative z-10">
                    BUKA UNDANGAN
                </span>

            </button>

        </div>

    </div>


    {{-- =========================================
         DECORATIVE ORNAMENT
    ========================================== --}}
    <div
        class="pointer-events-none absolute left-8 top-1/2 hidden -translate-y-1/2 text-neutral-400/40 sm:block"
    >
        <span class="text-4xl">
            ❦
        </span>
    </div>

    <div
        class="pointer-events-none absolute right-8 top-1/2 hidden -translate-y-1/2 text-neutral-400/40 sm:block"
    >
        <span class="text-4xl">
            ❦
        </span>
    </div>


    {{-- =========================================
         SCROLL INDICATOR
    ========================================== --}}
    <div
        class="absolute bottom-6 left-1/2 -translate-x-1/2 text-neutral-500"
    >

        <div class="flex flex-col items-center gap-2">

            <span
                class="text-[9px] tracking-[0.3em]"
            >
                SCROLL
            </span>

            <span
                class="cover-scroll-arrow text-sm"
            >
                ↓
            </span>

        </div>

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.cover-section {
    isolation: isolate;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.cover-orb {
    animation:
        coverOrbMove 12s ease-in-out infinite alternate;
}

.cover-orb-reverse {
    animation:
        coverOrbMoveReverse 14s ease-in-out infinite alternate;
}

@keyframes coverOrbMove {

    from {
        transform: translate3d(0, 0, 0) scale(1);
    }

    to {
        transform: translate3d(35px, 25px, 0) scale(1.08);
    }

}

@keyframes coverOrbMoveReverse {

    from {
        transform: translate3d(0, 0, 0) scale(1);
    }

    to {
        transform: translate3d(-35px, -25px, 0) scale(1.08);
    }

}


/* =========================================================
   PHOTO ENTRANCE
========================================================= */

.cover-photo-wrapper {
    opacity: 0;

    transform:
        translateY(30px)
        scale(.94);

    animation:
        coverPhotoIn 1.4s
        cubic-bezier(.22,1,.36,1)
        .25s forwards;
}

@keyframes coverPhotoIn {

    from {
        opacity: 0;

        transform:
            translateY(30px)
            scale(.94);
    }

    to {
        opacity: 1;

        transform:
            translateY(0)
            scale(1);
    }

}


/* =========================================================
   PHOTO SLOW ZOOM
========================================================= */

.cover-photo-image {
    transform: scale(1.02);

    animation:
        coverPhotoZoom 12s
        ease-in-out
        infinite alternate;

    transition:
        transform .7s ease;
}

.cover-photo:hover .cover-photo-image {
    transform: scale(1.07);
}

@keyframes coverPhotoZoom {

    from {
        transform: scale(1.02);
    }

    to {
        transform: scale(1.08);
    }

}


/* =========================================================
   TEXT REVEAL
========================================================= */

.cover-reveal {

    opacity: 0;

    transform:
        translateY(18px);

    animation:
        coverReveal 1s
        cubic-bezier(.22,1,.36,1)
        var(--delay)
        forwards;
}

@keyframes coverReveal {

    from {
        opacity: 0;

        transform:
            translateY(18px);
    }

    to {
        opacity: 1;

        transform:
            translateY(0);
    }

}


/* =========================================================
   NAMES
========================================================= */

.cover-name {
    transition:
        letter-spacing .5s ease;
}

.cover-name:hover {
    letter-spacing: .08em;
}


/* =========================================================
   AMPERSAND
========================================================= */

.cover-ampersand {
    animation:
        ampersandFloat 4s ease-in-out
        1.2s infinite;
}

@keyframes ampersandFloat {

    0%,
    100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-4px);
    }

}


/* =========================================================
   BUTTON
========================================================= */

.cover-button {
    position: relative;
}

.cover-button button {

    box-shadow:
        0 8px 25px rgba(0,0,0,.08);
}


/* =========================================================
   SCROLL
========================================================= */

.cover-scroll-arrow {

    animation:
        coverScroll 1.8s
        ease-in-out
        infinite;
}

@keyframes coverScroll {

    0%,
    100% {
        transform: translateY(0);
        opacity: .4;
    }

    50% {
        transform: translateY(7px);
        opacity: 1;
    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .cover-section {
        min-height: 100svh;
    }

    .cover-photo-wrapper {
        margin-top: 1.5rem;
    }

    .cover-name {
        font-size: 3rem;
    }

}


/* =========================================================
   REDUCE MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .cover-orb,
    .cover-orb-reverse,
    .cover-photo-wrapper,
    .cover-photo-image,
    .cover-reveal,
    .cover-ampersand,
    .cover-scroll-arrow {
        animation: none !important;
        transition: none !important;
    }

}

</style>