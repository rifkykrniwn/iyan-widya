<section
    id="event"
    class="event-section relative overflow-hidden bg-[#f3f3f1] px-4 py-24 sm:px-6 sm:py-28"
>

    {{-- Background --}}
    <div
        class="event-orb-one absolute -left-32 top-10 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="event-orb-two absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    <div class="relative z-10 mx-auto max-w-5xl">

        {{-- Header --}}
        <div class="event-header mb-14 text-center sm:mb-16">

            <p class="text-[10px] tracking-[0.45em] text-neutral-500">
                SAVE THE DATE
            </p>

            <div class="mx-auto mt-5 flex items-center justify-center gap-3">
                <span class="h-px w-10 bg-neutral-400"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-400"></span>
            </div>

            <h2 class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl">
                Acara Pernikahan
            </h2>

        </div>


        {{-- Event Cards --}}
        <div class="grid items-stretch gap-6 md:grid-cols-2 md:gap-8">

            @forelse ($wedding->events as $index => $event)

                <div
                    class="event-card flex h-full flex-col rounded-3xl border border-neutral-200 bg-white/70 p-6 text-center shadow-sm backdrop-blur-sm sm:p-8"
                    style="--delay: {{ $index * 0.2 }}s;"
                >

                    {{-- Number --}}
                    <div
                        class="event-number mx-auto flex h-10 w-10 items-center justify-center rounded-full border border-neutral-200 bg-white text-xs text-neutral-500"
                    >
                        {{ sprintf('%02d', $index + 1) }}
                    </div>


                    {{-- Title --}}
                    <p class="mt-5 text-[10px] font-medium tracking-[0.35em] text-neutral-500">
                        {{ strtoupper($event->title) }}
                    </p>


                    {{-- Ornament --}}
                    <div class="mx-auto my-6 flex items-center gap-2">

                        <span class="h-px w-8 bg-neutral-300"></span>

                        <span class="text-xs text-neutral-400">
                            ❦
                        </span>

                        <span class="h-px w-8 bg-neutral-300"></span>

                    </div>


                    {{-- Day --}}
                    <p class="text-sm text-neutral-600">
                        {{ $event->start_at->translatedFormat('l') }}
                    </p>


                    {{-- Date --}}
                    <p class="mt-1 text-2xl font-light text-neutral-900 sm:text-3xl">
                        {{ $event->start_at->translatedFormat('d F Y') }}
                    </p>


                    {{-- Time --}}
                    <div class="mt-6 border-y border-neutral-200 py-5">

                        <p class="text-[9px] tracking-[0.3em] text-neutral-400">
                            WAKTU
                        </p>

                        <p class="mt-2 text-lg font-medium text-neutral-900">

                            {{ $event->start_at->format('H.i') }}

                            @if ($event->end_at)
                                <span class="font-light text-neutral-400">
                                    —
                                </span>

                                {{ $event->end_at->format('H.i') }}
                            @endif

                            <span class="text-xs font-normal text-neutral-500">
                                WIB
                            </span>

                        </p>

                    </div>


                    {{-- Location --}}
                    <div class="mt-7 flex-1">

                        <p class="text-[9px] tracking-[0.3em] text-neutral-400">
                            TEMPAT
                        </p>

                        <p class="mt-3 text-sm font-medium text-neutral-800">
                            {{ $event->venue }}
                        </p>

                        <p class="mt-2 whitespace-pre-line text-sm leading-7 text-neutral-600">
                            {{ $event->address }}
                        </p>

                    </div>


                    {{-- Maps --}}
                    @if ($event->maps_url)

                        <div class="mt-7">

                            <a
                                href="{{ $event->maps_url }}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="inline-flex items-center gap-2 rounded-full border border-neutral-700 px-6 py-3 text-[9px] tracking-[0.2em] text-neutral-800 transition duration-500 hover:-translate-y-1 hover:bg-neutral-900 hover:text-white"
                            >
                                <span>↗</span>
                                <span>LIHAT LOKASI</span>
                            </a>

                        </div>

                    @endif

                </div>

            @empty

                <div class="col-span-full rounded-3xl bg-white p-10 text-center">

                    <p class="text-sm text-neutral-500">
                        Informasi acara belum tersedia.
                    </p>

                </div>

            @endforelse

        </div>


        {{-- =========================================
             SPECIAL DAY
        ========================================== --}}

        <div class="special-day mt-20 text-center sm:mt-24">

            <p class="text-[10px] tracking-[0.45em] text-neutral-500">
                OUR SPECIAL DAY
            </p>


            <div class="mx-auto mt-5 flex items-center justify-center gap-3">

                <span class="h-px w-8 bg-neutral-300"></span>

                <span class="text-xs text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-8 bg-neutral-300"></span>

            </div>


            <div class="mt-8 flex items-center justify-center gap-5 sm:gap-7">

                {{-- Day --}}
                <div class="date-item">

                    <p class="text-4xl font-light text-neutral-900 sm:text-5xl">
                        {{ $wedding->wedding_date->format('d') }}
                    </p>

                    <p class="mt-2 text-[8px] tracking-[0.3em] text-neutral-500">
                        TANGGAL
                    </p>

                </div>


                <span class="text-2xl font-light text-neutral-300 sm:text-3xl">
                    /
                </span>


                {{-- Month --}}
                <div class="date-item">

                    <p class="text-4xl font-light text-neutral-900 sm:text-5xl">
                        {{ $wedding->wedding_date->format('m') }}
                    </p>

                    <p class="mt-2 text-[8px] tracking-[0.3em] text-neutral-500">
                        BULAN
                    </p>

                </div>


                <span class="text-2xl font-light text-neutral-300 sm:text-3xl">
                    /
                </span>


                {{-- Year --}}
                <div class="date-item">

                    <p class="text-4xl font-light text-neutral-900 sm:text-5xl">
                        {{ $wedding->wedding_date->format('Y') }}
                    </p>

                    <p class="mt-2 text-[8px] tracking-[0.3em] text-neutral-500">
                        TAHUN
                    </p>

                </div>

            </div>


            <div class="mt-8 text-xl text-neutral-300">
                ❦
            </div>

        </div>

    </div>

</section>


<style>

/* =========================================================
   BACKGROUND
========================================================= */

.event-orb-one {
    animation: eventOrbOne 12s ease-in-out infinite alternate;
}

.event-orb-two {
    animation: eventOrbTwo 14s ease-in-out infinite alternate;
}

@keyframes eventOrbOne {

    from {
        transform: translate(0, 0) scale(1);
    }

    to {
        transform: translate(35px, 25px) scale(1.08);
    }

}

@keyframes eventOrbTwo {

    from {
        transform: translate(0, 0) scale(1);
    }

    to {
        transform: translate(-35px, -25px) scale(1.08);
    }

}


/* =========================================================
   HEADER
========================================================= */

.event-header {

    animation:
        eventHeaderIn
        1.1s
        cubic-bezier(.22,1,.36,1)
        both;

}

@keyframes eventHeaderIn {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}


/* =========================================================
   EVENT CARD
========================================================= */

.event-card {

    animation:
        eventCardIn
        1s
        cubic-bezier(.22,1,.36,1)
        var(--delay)
        both;

    transition:
        transform .5s ease,
        box-shadow .5s ease;

}


@keyframes eventCardIn {

    from {
        opacity: 0;
        transform: translateY(45px) scale(.97);
    }

    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }

}


.event-card:hover {

    transform: translateY(-7px);

    box-shadow:
        0 20px 40px rgba(0,0,0,.08);

}


/* =========================================================
   NUMBER
========================================================= */

.event-number {

    transition:
        transform .5s ease;

}

.event-card:hover .event-number {

    transform:
        rotate(8deg)
        scale(1.08);

}


/* =========================================================
   SPECIAL DAY
========================================================= */

.special-day {

    animation:
        specialDayIn
        1.2s
        cubic-bezier(.22,1,.36,1)
        .7s
        both;

}


@keyframes specialDayIn {

    from {
        opacity: 0;
        transform: translateY(35px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}


/* =========================================================
   DATE
========================================================= */

.date-item {

    transition:
        transform .5s ease;

}

.date-item:hover {

    transform:
        translateY(-5px);

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .event-card {

        padding: 1.5rem;

    }

}


/* =========================================================
   REDUCE MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .event-orb-one,
    .event-orb-two,
    .event-header,
    .event-card,
    .special-day {

        animation: none !important;

    }

}

</style>