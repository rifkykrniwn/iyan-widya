<section
    id="gallery"
    class="gallery-section relative overflow-hidden bg-[#eeeeec] px-6 py-24 sm:py-28"
>

    {{-- =====================================================
         BACKGROUND DECORATION
    ====================================================== --}}

    <div
        class="gallery-orb-one absolute -left-32 top-20 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="gallery-orb-two absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    {{-- =====================================================
         CONTENT
    ====================================================== --}}

    <div class="relative z-10 mx-auto max-w-5xl">


        {{-- =================================================
             HEADER
        ================================================== --}}

        <div class="gallery-header mb-14 text-center sm:mb-16">

            <p
                class="text-[10px] font-medium tracking-[0.45em] text-neutral-500"
            >
                OUR MOMENTS
            </p>


            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span class="h-px w-10 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-300"></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Galeri
            </h2>


            <p
                class="mx-auto mt-4 max-w-md text-sm leading-7 text-neutral-500"
            >
                Beberapa momen yang menjadi bagian dari perjalanan
                kisah kami.
            </p>

        </div>


        {{-- =================================================
             GALLERY GRID
        ================================================== --}}

        <div
            class="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-5"
        >

            @forelse (
                $wedding->galleries
                    ->sortBy('sort_order')
                as $index => $photo
            )

                <button
                    type="button"
                    class="gallery-item group relative overflow-hidden rounded-2xl bg-neutral-200 shadow-sm"
                    data-image="{{ asset($photo->image) }}"
                    style="--gallery-delay: {{ $index * 0.1 + 0.1 }}s;"
                >

                    {{-- =================================================
                         IMAGE
                    ================================================== --}}

                    <img
                        src="{{ asset($photo->image) }}"
                        alt="{{ $photo->caption ?? 'Momen pernikahan' }}"
                        class="gallery-image aspect-square w-full object-cover grayscale"
                        loading="lazy"
                    >


                    {{-- =================================================
                         OVERLAY
                    ================================================== --}}

                    <div
                        class="gallery-overlay absolute inset-0 flex items-center justify-center"
                    >

                        <span
                            class="gallery-zoom flex h-11 w-11 items-center justify-center rounded-full border border-white/0 bg-black/0 text-xl font-light text-white opacity-0"
                        >
                            +
                        </span>

                    </div>


                    {{-- =================================================
                         INNER BORDER
                    ================================================== --}}

                    <span
                        class="pointer-events-none absolute inset-0 rounded-2xl border border-white/0 transition duration-500 group-hover:border-white/50"
                    ></span>

                </button>

            @empty

                {{-- =================================================
                     EMPTY STATE
                ================================================== --}}

                <div
                    class="col-span-full rounded-3xl border border-dashed border-neutral-300 bg-white/50 px-6 py-14 text-center"
                >

                    <div
                        class="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-neutral-200 bg-white"
                    >
                        <span class="text-xl text-neutral-400">
                            ♡
                        </span>
                    </div>


                    <p class="mt-5 text-sm text-neutral-500">
                        Galeri belum tersedia.
                    </p>


                    <p class="mt-2 text-xs text-neutral-400">
                        Momen indah akan segera hadir di sini.
                    </p>

                </div>

            @endforelse

        </div>


        {{-- =================================================
             BOTTOM ORNAMENT
        ================================================== --}}

        @if ($wedding->galleries->count() > 0)

            <div
                class="gallery-bottom mt-14 pb-10 text-center sm:mt-16 sm:pb-12"
            >

                <div
                    class="mx-auto h-px w-12 bg-neutral-300"
                ></div>


                <span
                    class="mt-5 block text-xl text-neutral-300"
                >
                    ❦
                </span>

            </div>

        @endif

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.gallery-section {

    isolation:
        isolate;

    scroll-margin-top:
        20px;

}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.gallery-orb-one {

    animation:
        galleryOrbOne
        13s
        ease-in-out
        infinite
        alternate;

}


.gallery-orb-two {

    animation:
        galleryOrbTwo
        15s
        ease-in-out
        infinite
        alternate;

}


@keyframes galleryOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(35px, 25px, 0)
            scale(1.08);

    }

}


@keyframes galleryOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-35px, -25px, 0)
            scale(1.08);

    }

}


/* =========================================================
   HEADER
========================================================= */

.gallery-header {

    opacity:
        0;

    transform:
        translateY(25px);

    animation:
        galleryHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        .1s
        forwards;

}


@keyframes galleryHeaderIn {

    from {

        opacity:
            0;

        transform:
            translateY(25px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   GALLERY ITEM
========================================================= */

.gallery-item {

    opacity:
        0;

    transform:
        translateY(30px)
        scale(.97);

    animation:
        galleryItemIn
        .9s
        cubic-bezier(.22,1,.36,1)
        var(--gallery-delay)
        forwards;

    cursor:
        pointer;

    -webkit-tap-highlight-color:
        transparent;

    transition:
        transform .5s ease,
        box-shadow .5s ease;

}


@keyframes galleryItemIn {

    from {

        opacity:
            0;

        transform:
            translateY(30px)
            scale(.97);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0)
            scale(1);

    }

}


/* =========================================================
   IMAGE
========================================================= */

.gallery-image {

    display:
        block;

    transform:
        scale(1.01);

    filter:
        grayscale(1);

    transition:
        transform 1s cubic-bezier(.22,1,.36,1),
        filter .8s ease;

}


.gallery-item:hover {

    transform:
        translateY(-3px);

    box-shadow:
        0 15px 30px rgba(0,0,0,.09);

}


.gallery-item:hover .gallery-image {

    transform:
        scale(1.08);

    filter:
        grayscale(.15);

}


/* =========================================================
   OVERLAY
========================================================= */

.gallery-overlay {

    background:
        rgba(0,0,0,0);

    transition:
        background-color .5s ease;

}


.gallery-item:hover .gallery-overlay {

    background:
        rgba(0,0,0,.16);

}


/* =========================================================
   ZOOM ICON
========================================================= */

.gallery-zoom {

    transform:
        scale(.65);

    transition:
        opacity .4s ease,
        transform .5s cubic-bezier(.22,1,.36,1),
        background-color .4s ease,
        border-color .4s ease;

}


.gallery-item:hover .gallery-zoom {

    opacity:
        1;

    transform:
        scale(1);

    border-color:
        rgba(255,255,255,.7);

    background:
        rgba(0,0,0,.2);

}


/* =========================================================
   BOTTOM ORNAMENT
========================================================= */

.gallery-bottom {

    opacity:
        0;

    animation:
        galleryBottomIn
        1s
        ease-out
        1s
        forwards;

}


@keyframes galleryBottomIn {

    from {

        opacity:
            0;

        transform:
            translateY(15px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .gallery-section {

        padding-top:
            5rem;

        padding-bottom:
            6rem;

    }


    .gallery-item {

        border-radius:
            1rem;

    }


    .gallery-item:hover {

        transform:
            none;

    }


    .gallery-zoom {

        /*
        Pada layar sentuh tidak perlu
        selalu menampilkan tombol +.
        */

        height:
            2.25rem;

        width:
            2.25rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .gallery-orb-one,
    .gallery-orb-two,
    .gallery-header,
    .gallery-item,
    .gallery-bottom {

        animation:
            none !important;

        opacity:
            1;

        transform:
            none;

    }


    .gallery-image,
    .gallery-overlay,
    .gallery-zoom {

        transition:
            none !important;

    }

}

</style>