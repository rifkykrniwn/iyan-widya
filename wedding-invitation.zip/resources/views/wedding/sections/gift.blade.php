<section
    id="gift"
    class="relative overflow-hidden bg-[#eeeeec] px-6 py-24"
>
    <div class="absolute -left-32 top-20 h-72 w-72 rounded-full bg-white/60 blur-3xl"></div>

    <div class="absolute -bottom-32 -right-32 h-72 w-72 rounded-full bg-white/60 blur-3xl"></div>


    <div class="relative z-10 mx-auto max-w-3xl">

        {{-- Header --}}
        <div class="mb-12 text-center">

            <p class="text-[10px] tracking-[0.4em] text-neutral-500">
                WEDDING GIFT
            </p>

            <h2 class="mt-4 text-3xl font-light tracking-wide text-neutral-900">
                Tanda Kasih
            </h2>

            <p class="mx-auto mt-4 max-w-md text-sm leading-7 text-neutral-500">
                Doa dan kehadiran Anda merupakan hadiah terindah
                bagi kami. Namun apabila ingin memberikan tanda kasih,
                dapat melalui informasi berikut.
            </p>

        </div>


        {{-- Gift --}}
        <div class="space-y-5">

            @forelse ($wedding->gifts as $gift)

                {{-- Bank --}}
                @if ($gift->type === 'bank')

                    <div
                        class="rounded-3xl border border-neutral-200 bg-white/70 p-7 shadow-sm"
                    >

                        <div class="flex items-start justify-between gap-4">

                            <div>

                                <p class="text-[10px] tracking-[0.3em] text-neutral-500">
                                    BANK
                                </p>

                                <h3 class="mt-2 text-xl font-medium text-neutral-900">
                                    {{ $gift->bank_name }}
                                </h3>

                            </div>

                            <div class="text-2xl">
                                ♡
                            </div>

                        </div>


                        <div class="mt-7">

                            <p class="text-xs text-neutral-500">
                                Nomor Rekening
                            </p>

                            <div class="mt-2 flex items-center gap-3">

                                <p
                                    id="account-{{ $gift->id }}"
                                    class="text-lg tracking-wider text-neutral-900"
                                >
                                    {{ $gift->account_number }}
                                </p>

                                <button
                                    type="button"
                                    onclick="copyAccount('{{ $gift->account_number }}')"
                                    class="rounded-full border border-neutral-300 px-4 py-2 text-[9px] tracking-[0.15em] text-neutral-700 transition hover:bg-neutral-900 hover:text-white"
                                >
                                    SALIN
                                </button>

                            </div>

                        </div>


                        <div class="mt-5">

                            <p class="text-xs text-neutral-500">
                                Atas Nama
                            </p>

                            <p class="mt-1 text-sm text-neutral-800">
                                {{ $gift->account_name }}
                            </p>

                        </div>

                    </div>

                @endif


                {{-- Alamat Pengiriman --}}
                @if ($gift->type === 'address')

                    <div
                        class="rounded-3xl border border-neutral-200 bg-white/70 p-7 shadow-sm"
                    >

                        <div class="flex items-start justify-between gap-4">

                            <div>

                                <p class="text-[10px] tracking-[0.3em] text-neutral-500">
                                    ALAMAT PENGIRIMAN
                                </p>

                                <h3 class="mt-2 text-xl font-medium text-neutral-900">
                                    Kirim Hadiah
                                </h3>

                            </div>

                            <div class="text-2xl">
                                ♡
                            </div>

                        </div>


                        <div class="mt-7">

                            <p class="text-xs text-neutral-500">
                                Alamat
                            </p>

                            <p
                                id="address-{{ $gift->id }}"
                                class="mt-2 whitespace-pre-line text-sm leading-7 text-neutral-800"
                            >
                                {{ $gift->address }}
                            </p>


                            <button
                                type="button"
                                onclick="copyAddress(`{{ addslashes($gift->address) }}`)"
                                class="mt-4 rounded-full border border-neutral-300 px-4 py-2 text-[9px] tracking-[0.15em] text-neutral-700 transition hover:bg-neutral-900 hover:text-white"
                            >
                                SALIN ALAMAT
                            </button>

                        </div>

                    </div>

                @endif


            @empty

                <div class="py-10 text-center">

                    <p class="text-sm text-neutral-500">
                        Informasi hadiah belum tersedia.
                    </p>

                </div>

            @endforelse

        </div>

    </div>

</section>


<script>
    function copyAccount(accountNumber) {

        navigator.clipboard.writeText(accountNumber)
            .then(() => {

                alert('Nomor rekening berhasil disalin.');

            })
            .catch(() => {

                alert('Gagal menyalin nomor rekening.');

            });

    }


    function copyAddress(address) {

        navigator.clipboard.writeText(address)
            .then(() => {

                alert('Alamat berhasil disalin.');

            })
            .catch(() => {

                alert('Gagal menyalin alamat.');

            });

    }
</script>