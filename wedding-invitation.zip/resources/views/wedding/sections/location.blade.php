<section
    id="location"
    class="location-section relative overflow-hidden bg-[#f3f3f1] px-4 py-20 sm:px-6 sm:py-28"
>

    {{-- =========================================
         DECORATIVE BACKGROUND
    ========================================== --}}

    <div
        class="location-orb-one absolute -left-32 top-20 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="location-orb-two absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    {{-- =========================================
         MAIN CONTENT
    ========================================== --}}

    <div class="relative z-10 mx-auto max-w-5xl">


        {{-- =========================================
             HEADER
        ========================================== --}}

        <div class="location-header mb-14 text-center">

            <p
                class="text-[10px] font-medium tracking-[0.45em] text-neutral-500"
            >
                LOCATION
            </p>


            {{-- Ornament --}}

            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span class="h-px w-10 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-300"></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Lokasi Acara
            </h2>


            <p
                class="mx-auto mt-5 max-w-md text-sm leading-7 text-neutral-500"
            >
                Kami dengan senang hati menantikan kehadiran
                Anda di hari istimewa kami.
            </p>

        </div>


        {{-- =========================================
             LOCATION CARDS
        ========================================== --}}

        <div class="grid items-stretch gap-6 md:grid-cols-2 md:gap-8">

            @foreach ($wedding->events as $event)

                <div
                    class="location-card group flex h-full flex-col overflow-hidden rounded-[2rem] border border-neutral-200/80 bg-white/75 shadow-sm"
                    style="--location-delay: {{ $loop->index * 0.18 + 0.15 }}s;"
                >

                    {{-- =================================
                         LOCATION HEADER / MAP AREA
                    ================================== --}}

                    <div
                        class="location-map relative flex h-52 shrink-0 items-center justify-center overflow-hidden bg-[#e5e5e2] sm:h-60"
                    >

                        {{-- Decorative circles --}}

                        <div
                            class="absolute h-40 w-40 rounded-full border border-neutral-300/70"
                        ></div>

                        <div
                            class="absolute h-28 w-28 rounded-full border border-neutral-300/50"
                        ></div>

                        <div
                            class="absolute h-16 w-16 rounded-full border border-neutral-300/40"
                        ></div>


                        {{-- Location icon --}}

                        <div
                            class="location-pin relative z-10 flex h-16 w-16 items-center justify-center rounded-full border border-white/80 bg-white/70 shadow-sm backdrop-blur-sm"
                        >

                            <span class="text-2xl">
                                📍
                            </span>

                        </div>


                        {{-- Event label --}}

                        <div
                            class="absolute bottom-5 left-0 right-0 text-center"
                        >

                            <span
                                class="rounded-full border border-white/70 bg-white/60 px-4 py-2 text-[9px] font-medium tracking-[0.25em] text-neutral-600 backdrop-blur-sm"
                            >
                                {{ strtoupper($event->title) }}
                            </span>

                        </div>

                    </div>


                    {{-- =================================
                         CONTENT
                    ================================== --}}

                    <div
                        class="flex flex-1 flex-col p-6 text-center sm:p-8"
                    >

                        {{-- Event label --}}

                        <p
                            class="text-[9px] font-medium tracking-[0.35em] text-neutral-400"
                        >
                            {{ strtoupper($event->title) }}
                        </p>


                        {{-- Venue --}}

                        <div
                            class="mt-4 flex min-h-[58px] items-center justify-center"
                        >

                            <h3
                                class="text-xl font-light leading-7 text-neutral-900 transition duration-500 group-hover:tracking-wide"
                            >
                                {{ $event->venue }}
                            </h3>

                        </div>


                        {{-- Small divider --}}

                        <div
                            class="mx-auto mt-5 h-px w-8 bg-neutral-300"
                        ></div>


                        {{-- Address --}}

                        <div
                            class="mt-5 flex min-h-[72px] items-start justify-center"
                        >

                            <p
                                class="whitespace-pre-line text-sm leading-7 text-neutral-600"
                            >
                                {{ $event->address }}
                            </p>

                        </div>


                        {{-- Google Maps button --}}

                        <div
                            class="mt-auto pt-7"
                        >

                            @if ($event->maps_url)

                                <a
                                    href="{{ $event->maps_url }}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    class="location-button inline-flex items-center gap-3 rounded-full border border-neutral-700 px-7 py-3 text-[10px] font-medium tracking-[0.2em] text-neutral-800 transition-all duration-500 hover:-translate-y-1 hover:bg-neutral-900 hover:text-white hover:shadow-lg"
                                >

                                    <span>
                                        BUKA GOOGLE MAPS
                                    </span>

                                    <span
                                        class="text-sm transition-transform duration-500 group-hover:translate-x-1"
                                    >
                                        →
                                    </span>

                                </a>

                            @else

                                <span
                                    class="text-[10px] tracking-[0.2em] text-neutral-400"
                                >
                                    LOKASI AKAN SEGERA DITAMBAHKAN
                                </span>

                            @endif

                        </div>

                    </div>

                </div>

            @endforeach

        </div>


        {{-- =========================================
             BOTTOM ORNAMENT
        ========================================== --}}

        <div
            class="location-bottom mt-14 text-center"
        >

            <div
                class="mx-auto flex items-center justify-center gap-4"
            >

                <span class="h-px w-12 bg-neutral-300"></span>

                <span class="text-lg text-neutral-400">
                    ♡
                </span>

                <span class="h-px w-12 bg-neutral-300"></span>

            </div>

        </div>

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.location-section {
    isolation: isolate;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.location-orb-one {

    animation:
        locationOrbOne
        13s
        ease-in-out
        infinite
        alternate;

}


.location-orb-two {

    animation:
        locationOrbTwo
        15s
        ease-in-out
        infinite
        alternate;

}


@keyframes locationOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(35px, 25px, 0)
            scale(1.08);

    }

}


@keyframes locationOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-35px, -25px, 0)
            scale(1.08);

    }

}


/* =========================================================
   HEADER
========================================================= */

.location-header {

    opacity: 0;

    transform:
        translateY(25px);

    animation:
        locationHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        .1s
        forwards;

}


@keyframes locationHeaderIn {

    from {

        opacity: 0;

        transform:
            translateY(25px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   LOCATION CARD
========================================================= */

.location-card {

    opacity: 0;

    transform:
        translateY(35px)
        scale(.97);

    animation:
        locationCardIn
        1s
        cubic-bezier(.22,1,.36,1)
        var(--location-delay)
        forwards;

    transition:
        transform .5s ease,
        box-shadow .5s ease;

}


.location-card:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 20px 45px rgba(0,0,0,.07);

}


@keyframes locationCardIn {

    from {

        opacity: 0;

        transform:
            translateY(35px)
            scale(.97);

    }

    to {

        opacity: 1;

        transform:
            translateY(0)
            scale(1);

    }

}


/* =========================================================
   MAP AREA
========================================================= */

.location-map {

    transition:
        background-color .5s ease;

}


.location-card:hover .location-map {

    background-color:
        #dededb;

}


/* =========================================================
   LOCATION PIN
========================================================= */

.location-pin {

    animation:
        locationPinFloat
        4s
        ease-in-out
        infinite;

    transition:
        transform .5s ease,
        box-shadow .5s ease;

}


.location-card:hover .location-pin {

    transform:
        scale(1.08);

    box-shadow:
        0 10px 25px rgba(0,0,0,.08);

}


@keyframes locationPinFloat {

    0%,
    100% {

        transform:
            translateY(0);

    }

    50% {

        transform:
            translateY(-5px);

    }

}


/* =========================================================
   BUTTON
========================================================= */

.location-button {

    box-shadow:
        0 5px 15px rgba(0,0,0,.04);

}


/* =========================================================
   BOTTOM
========================================================= */

.location-bottom {

    opacity: 0;

    animation:
        locationBottomIn
        1s
        ease-out
        1s
        forwards;

}


@keyframes locationBottomIn {

    from {

        opacity: 0;

        transform:
            translateY(15px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .location-section {

        padding-top:
            5rem;

        padding-bottom:
            5rem;

    }

    .location-card {

        border-radius:
            1.75rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .location-orb-one,
    .location-orb-two,
    .location-header,
    .location-card,
    .location-pin,
    .location-bottom {

        animation:
            none !important;

        transition:
            none !important;

        opacity: 1;

        transform: none;

    }

}

</style>