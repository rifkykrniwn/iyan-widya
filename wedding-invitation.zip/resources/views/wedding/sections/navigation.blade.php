<nav
    id="bottomNavigation"
    class="fixed bottom-0 left-1/2 z-[80] w-full max-w-lg -translate-x-1/2 border-t border-neutral-200 bg-[#f3f3f1]/95 px-4 py-3 shadow-lg backdrop-blur-md"
>

    <div class="grid grid-cols-5 gap-1">

        {{-- HOME --}}
        <a
            href="#cover"
            data-nav-target="cover"
            class="nav-item flex flex-col items-center gap-1.5 text-neutral-400 transition duration-300"
        >

            <span class="nav-icon">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.7"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                >
                    <path d="M3 10.5L12 3l9 7.5"></path>
                    <path d="M5.5 9.5V21h13V9.5"></path>
                    <path d="M9.5 21v-6h5v6"></path>
                </svg>
            </span>

            <span class="nav-label">
                HOME
            </span>

        </a>


        {{-- COUPLE --}}
        <a
            href="#couple"
            data-nav-target="couple"
            class="nav-item flex flex-col items-center gap-1.5 text-neutral-400 transition duration-300"
        >

            <span class="nav-icon">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.7"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                >
                    <circle cx="9" cy="8" r="3"></circle>
                    <circle cx="17" cy="9" r="2.5"></circle>
                    <path d="M3.5 20c.4-3.7 2.4-5.5 5.5-5.5s5.1 1.8 5.5 5.5"></path>
                    <path d="M14 14.5c2.8-.8 5.4.7 6 3.5"></path>
                </svg>
            </span>

            <span class="nav-label">
                COUPLE
            </span>

        </a>


        {{-- EVENT --}}
        <a
            href="#event"
            data-nav-target="event"
            class="nav-item flex flex-col items-center gap-1.5 text-neutral-400 transition duration-300"
        >

            <span class="nav-icon">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.7"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                >
                    <rect
                        x="3.5"
                        y="5"
                        width="17"
                        height="16"
                        rx="2"
                    ></rect>

                    <path d="M7 3v4"></path>
                    <path d="M17 3v4"></path>
                    <path d="M3.5 9h17"></path>

                    <path d="M8 13h.01"></path>
                    <path d="M12 13h.01"></path>
                    <path d="M16 13h.01"></path>
                    <path d="M8 17h.01"></path>
                    <path d="M12 17h.01"></path>
                </svg>
            </span>

            <span class="nav-label">
                EVENT
            </span>

        </a>


        {{-- WISHES --}}
        <a
            href="#wishes"
            data-nav-target="wishes"
            class="nav-item flex flex-col items-center gap-1.5 text-neutral-400 transition duration-300"
        >

            <span class="nav-icon">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.7"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                >
                    <path d="M20.8 8.8c0 5.5-8.8 10-8.8 10s-8.8-4.5-8.8-10A4.8 4.8 0 0 1 12 6.1a4.8 4.8 0 0 1 8.8 2.7Z"></path>
                </svg>
            </span>

            <span class="nav-label">
                WISHES
            </span>

        </a>


        {{-- GIFT --}}
        <a
            href="#gift"
            data-nav-target="gift"
            class="nav-item flex flex-col items-center gap-1.5 text-neutral-400 transition duration-300"
        >

            <span class="nav-icon">
                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.7"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                >
                    <rect
                        x="3"
                        y="8"
                        width="18"
                        height="13"
                        rx="2"
                    ></rect>

                    <path d="M12 8v13"></path>
                    <path d="M3 12h18"></path>

                    <path d="M12 8H8.5A2.5 2.5 0 1 1 11 5.5L12 8Z"></path>
                    <path d="M12 8h3.5A2.5 2.5 0 1 0 13 5.5L12 8Z"></path>
                </svg>
            </span>

            <span class="nav-label">
                GIFT
            </span>

        </a>

    </div>

</nav>


<style>

/* =========================================================
   NAV ICON
========================================================= */

.nav-icon {

    display: flex;

    height: 17px;

    width: 17px;

    align-items: center;

    justify-content: center;

    transition:
        color .3s ease,
        transform .3s ease;
}


.nav-icon svg {

    height: 100%;

    width: 100%;
}


/* =========================================================
   LABEL
========================================================= */

.nav-label {

    font-size: 8px;

    font-weight: 500;

    line-height: 1;

    letter-spacing: .15em;

    transition:
        color .3s ease;
}


/* =========================================================
   HOVER
========================================================= */

.nav-item:hover {

    color:
        rgb(82 82 82);

}


.nav-item:hover .nav-icon {

    transform:
        translateY(-1px);

}


/* =========================================================
   ACTIVE
========================================================= */

.nav-item.active {

    color:
        rgb(23 23 23);

}


.nav-item.active .nav-icon {

    color:
        rgb(23 23 23);

    transform:
        translateY(-1px)
        scale(1.05);

}


.nav-item.active .nav-label {

    color:
        rgb(23 23 23);

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    #bottomNavigation {

        width:
            100%;

        max-width:
            32rem;

        padding-left:
            1rem;

        padding-right:
            1rem;

    }


    .nav-item {

        gap:
            5px;

    }


    .nav-icon {

        height:
            16px;

        width:
            16px;

    }


    .nav-label {

        font-size:
            7px;

    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const navItems =
        document.querySelectorAll('.nav-item');

    const sections =
        document.querySelectorAll(
            '#cover, #couple, #event, #wishes, #gift'
        );


    /*
    ========================================================
    CLICK
    ========================================================
    */

    navItems.forEach(function (item) {

        item.addEventListener('click', function (event) {

            const targetId =
                item.getAttribute('data-nav-target');

            const target =
                document.getElementById(targetId);


            if (!target) {
                return;
            }


            event.preventDefault();


            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });

        });

    });


    /*
    ========================================================
    ACTIVE NAVIGATION
    ========================================================
    */

    function updateActiveNavigation() {

        const scrollPosition =
            window.scrollY +
            (window.innerHeight * 0.35);


        let currentSection =
            'cover';


        sections.forEach(function (section) {

            if (
                scrollPosition >=
                section.offsetTop
            ) {

                currentSection =
                    section.id;

            }

        });


        navItems.forEach(function (item) {

            const target =
                item.getAttribute('data-nav-target');


            item.classList.toggle(
                'active',
                target === currentSection
            );

        });

    }


    /*
    ========================================================
    INITIAL
    ========================================================
    */

    updateActiveNavigation();


    /*
    ========================================================
    SCROLL
    ========================================================
    */

    let ticking = false;


    window.addEventListener(
        'scroll',
        function () {

            if (!ticking) {

                window.requestAnimationFrame(
                    function () {

                        updateActiveNavigation();

                        ticking = false;

                    }
                );

                ticking = true;

            }

        },
        {
            passive: true
        }
    );

});

</script>