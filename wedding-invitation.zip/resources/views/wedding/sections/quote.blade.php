<section
    id="quote"
    class="quote-section relative flex min-h-screen items-center justify-center overflow-hidden bg-[#f3f3f1] px-6 py-24"
>

    {{-- Background decoration --}}

    <div
        class="quote-orb-one absolute -left-32 top-20 h-64 w-64 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="quote-orb-two absolute -bottom-32 -right-32 h-72 w-72 rounded-full bg-white/70 blur-3xl"
    ></div>


    {{-- Content --}}

    <div
        class="relative z-10 mx-auto w-full max-w-2xl text-center"
    >


        {{-- =========================================
             BISMILLAH
        ========================================== --}}

        <p
            class="quote-bismillah text-[10px] tracking-[0.35em] text-neutral-500 sm:text-xs sm:tracking-[0.4em]"
        >
            BISMILLAHIRRAHMANIRRAHIM
        </p>


        {{-- =========================================
             ARABIC
        ========================================== --}}

        <p
            dir="rtl"
            lang="ar"
            class="quote-arabic mt-10 text-[22px] leading-[2.35] text-neutral-900 sm:mt-12 sm:text-3xl sm:leading-[2.4]"
        >
            وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ
            أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم
            مَّوَدَّةً وَرَحْمَةً ۚ إِنَّ فِي ذَٰلِكَ لَآيَاتٍ
            لِّقَوْمٍ يَتَفَكَّرُونَ
        </p>


        {{-- =========================================
             DIVIDER
        ========================================== --}}

        <div
            class="quote-divider mx-auto mt-10 h-px w-12 bg-neutral-400 sm:mt-12"
        ></div>


        {{-- =========================================
             TRANSLATION
        ========================================== --}}

        <p
            class="quote-translation mx-auto mt-10 max-w-xl whitespace-pre-line text-[14px] leading-8 text-neutral-700 sm:mt-10 sm:text-base sm:leading-9"
        >
            {{ $wedding->quote }}
        </p>


        {{-- =========================================
             SURAH
        ========================================== --}}

        <p
            class="quote-surah mt-8 pb-8 text-[11px] tracking-[0.12em] text-neutral-500 sm:mt-10 sm:pb-12 sm:text-sm"
        >
            ( QS. Ar Ruum : 21 )
        </p>


    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.quote-section {

    isolation: isolate;

    /*
    Saat navigation diklik,
    section tidak terlalu mepet dengan bagian atas.
    */

    scroll-margin-top:
        20px;

}


/* =========================================================
   BACKGROUND
========================================================= */

.quote-orb-one {

    animation:
        quoteOrbOne
        13s
        ease-in-out
        infinite
        alternate;

}


.quote-orb-two {

    animation:
        quoteOrbTwo
        15s
        ease-in-out
        infinite
        alternate;

}


@keyframes quoteOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(30px, 20px, 0)
            scale(1.08);

    }

}


@keyframes quoteOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-30px, -20px, 0)
            scale(1.08);

    }

}


/* =========================================================
   INITIAL ANIMATION
========================================================= */

.quote-bismillah,
.quote-arabic,
.quote-divider,
.quote-translation,
.quote-surah {

    opacity:
        0;

    transform:
        translateY(20px);

    animation:
        quoteReveal
        1s
        cubic-bezier(.22,1,.36,1)
        forwards;

}


.quote-bismillah {

    animation-delay:
        .1s;

}


.quote-arabic {

    animation-delay:
        .25s;

}


.quote-divider {

    animation-delay:
        .45s;

}


.quote-translation {

    animation-delay:
        .6s;

}


.quote-surah {

    animation-delay:
        .8s;

}


@keyframes quoteReveal {

    from {

        opacity:
            0;

        transform:
            translateY(20px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .quote-section {

        /*
        Memberikan sedikit ruang tambahan
        untuk navigation fixed.
        */

        padding-top:
            5rem;

        padding-bottom:
            7rem;

    }


    .quote-arabic {

        font-size:
            22px;

        line-height:
            2.3;

    }


    .quote-translation {

        max-width:
            21rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .quote-orb-one,
    .quote-orb-two,
    .quote-bismillah,
    .quote-arabic,
    .quote-divider,
    .quote-translation,
    .quote-surah {

        animation:
            none !important;

        transition:
            none !important;

        opacity:
            1;

        transform:
            none;

    }

}

</style>