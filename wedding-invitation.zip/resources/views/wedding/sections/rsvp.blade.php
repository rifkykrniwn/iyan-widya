<section
    id="rsvp"
    class="rsvp-section relative overflow-hidden bg-[#eeeeec] px-6 py-24 sm:py-28"
>

    {{-- =========================================
         BACKGROUND
    ========================================== --}}

    <div
        class="rsvp-orb-one absolute -left-32 top-20 h-80 w-80 rounded-full bg-white/60 blur-3xl"
    ></div>

    <div
        class="rsvp-orb-two absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-white/60 blur-3xl"
    ></div>


    {{-- =========================================
         MAIN CONTENT
    ========================================== --}}

    <div class="relative z-10 mx-auto max-w-xl">


        {{-- =========================================
             HEADER
        ========================================== --}}

        <div class="rsvp-header mb-12 text-center">

            <p
                class="text-[10px] font-medium tracking-[0.45em] text-neutral-500"
            >
                RSVP
            </p>


            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span class="h-px w-10 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-300"></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Konfirmasi Kehadiran
            </h2>


            <p
                class="mx-auto mt-5 max-w-md text-sm leading-7 text-neutral-500"
            >
                Mohon konfirmasi kehadiran Anda untuk membantu kami
                mempersiapkan hari bahagia ini.
            </p>

        </div>


        {{-- =========================================
             SUCCESS POPUP
        ========================================== --}}

        @if (session('success'))

            <div
                id="successPopup"
                class="rsvp-popup fixed inset-0 z-[99999] flex items-center justify-center bg-black/45 px-6 backdrop-blur-[4px]"
            >

                <div
                    class="rsvp-popup-box w-full max-w-sm rounded-[2rem] border border-white/50 bg-[#f3f3f1] p-8 text-center shadow-2xl sm:p-10"
                >

                    {{-- Icon --}}

                    <div
                        class="rsvp-success-icon mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-neutral-300 bg-white"
                    >

                        <span
                            class="text-2xl font-light text-neutral-700"
                        >
                            ✓
                        </span>

                    </div>


                    {{-- Title --}}

                    <h3
                        class="mt-6 text-2xl font-light tracking-wide text-neutral-900"
                    >
                        Terima Kasih
                    </h3>


                    {{-- Message --}}

                    <p
                        class="mt-3 text-sm leading-7 text-neutral-600"
                    >
                        Konfirmasi kehadiran dan ucapan Anda
                        telah berhasil dikirim.
                    </p>


                    {{-- Ornament --}}

                    <div
                        class="mx-auto mt-5 flex items-center justify-center gap-3"
                    >

                        <span class="h-px w-8 bg-neutral-300"></span>

                        <span class="text-xs text-neutral-400">
                            ♡
                        </span>

                        <span class="h-px w-8 bg-neutral-300"></span>

                    </div>


                    {{-- Close --}}

                    <button
                        type="button"
                        onclick="
                            document.getElementById('successPopup').remove();
                            document.body.classList.remove('overflow-hidden');
                        "
                        class="mt-7 w-full cursor-pointer rounded-full bg-neutral-900 px-6 py-3.5 text-[10px] font-medium tracking-[0.25em] text-white transition duration-300 hover:-translate-y-0.5 hover:bg-neutral-700 hover:shadow-lg"
                    >
                        TUTUP
                    </button>

                </div>

            </div>


            <script>
                document.body.classList.add('overflow-hidden');
            </script>

        @endif


        {{-- =========================================
             VALIDATION
        ========================================== --}}

        @if ($errors->any())

            <div
                class="rsvp-error mb-8 rounded-2xl border border-red-200 bg-red-50/70 p-5 text-sm text-red-700 shadow-sm"
            >

                <div class="flex items-start gap-3">

                    <span class="mt-0.5 text-sm">
                        !
                    </span>

                    <div>

                        <p class="font-medium">
                            Mohon periksa kembali:
                        </p>

                        <ul class="mt-2 list-inside list-disc space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>

                    </div>

                </div>

            </div>

        @endif


        {{-- =========================================
             RSVP FORM
        ========================================== --}}

        <form
            action="{{ request()->route('guestSlug')
                ? route('wedding.guest.rsvp', [
                    'slug' => $wedding->slug,
                    'guestSlug' => request()->route('guestSlug'),
                ])
                : route('wedding.rsvp', $wedding->slug) }}"
            method="POST"
            class="rsvp-form"
        >

            @csrf


            {{-- =====================================
                 NAME
            ====================================== --}}

            <div class="rsvp-field">

                <label
                    for="name"
                    class="text-[10px] font-medium tracking-[0.25em] text-neutral-600"
                >
                    NAMA
                </label>


                <div class="relative mt-3">

                    <input
                        id="name"
                        name="name"
                        type="text"
                        value="{{ old('name', $guest->name ?? '') }}"
                        required
                        maxlength="100"
                        placeholder="Masukkan nama Anda"
                        @if(isset($guest)) readonly @endif
                        class="w-full rounded-2xl border border-neutral-200 bg-white px-5 py-4 text-sm text-neutral-800 outline-none transition duration-300 placeholder:text-neutral-400 focus:border-neutral-500 focus:ring-2 focus:ring-neutral-200/60 @if(isset($guest)) bg-neutral-100 text-neutral-500 @endif"
                    >

                    @if(isset($guest))

                        <span
                            class="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-neutral-400"
                        >
                            ✓
                        </span>

                    @endif

                </div>

            </div>


            {{-- =====================================
                 ATTENDANCE
            ====================================== --}}

            <div class="rsvp-field mt-8">

                <p
                    class="text-[10px] font-medium tracking-[0.25em] text-neutral-600"
                >
                    KONFIRMASI KEHADIRAN
                </p>


                <div class="mt-4 space-y-3">


                    {{-- HADIR --}}

                    <label class="attendance-option group">

                        <input
                            type="radio"
                            name="attendance"
                            value="hadir"
                            {{ old('attendance') === 'hadir' ? 'checked' : '' }}
                            required
                            class="peer sr-only"
                        >

                        <div
                            class="attendance-card"
                        >

                            <div
                                class="attendance-icon"
                            >
                                ✓
                            </div>

                            <div class="flex-1">

                                <p
                                    class="text-sm font-medium text-neutral-800"
                                >
                                    Saya akan hadir
                                </p>

                                <p
                                    class="mt-1 text-xs text-neutral-400"
                                >
                                    Dengan senang hati hadir di acara
                                </p>

                            </div>

                            <div
                                class="attendance-check"
                            >
                                ✓
                            </div>

                        </div>

                    </label>


                    {{-- TIDAK HADIR --}}

                    <label class="attendance-option group">

                        <input
                            type="radio"
                            name="attendance"
                            value="tidak_hadir"
                            {{ old('attendance') === 'tidak_hadir' ? 'checked' : '' }}
                            class="peer sr-only"
                        >

                        <div
                            class="attendance-card"
                        >

                            <div
                                class="attendance-icon"
                            >
                                —
                            </div>

                            <div class="flex-1">

                                <p
                                    class="text-sm font-medium text-neutral-800"
                                >
                                    Saya tidak dapat hadir
                                </p>

                                <p
                                    class="mt-1 text-xs text-neutral-400"
                                >
                                    Mohon maaf tidak dapat hadir
                                </p>

                            </div>

                            <div
                                class="attendance-check"
                            >
                                ✓
                            </div>

                        </div>

                    </label>


                    {{-- RAGU --}}

                    <label class="attendance-option group">

                        <input
                            type="radio"
                            name="attendance"
                            value="ragu"
                            {{ old('attendance') === 'ragu' ? 'checked' : '' }}
                            class="peer sr-only"
                        >

                        <div
                            class="attendance-card"
                        >

                            <div
                                class="attendance-icon"
                            >
                                ?
                            </div>

                            <div class="flex-1">

                                <p
                                    class="text-sm font-medium text-neutral-800"
                                >
                                    Masih ragu
                                </p>

                                <p
                                    class="mt-1 text-xs text-neutral-400"
                                >
                                    Akan kami informasikan kembali
                                </p>

                            </div>

                            <div
                                class="attendance-check"
                            >
                                ✓
                            </div>

                        </div>

                    </label>


                </div>

            </div>


            {{-- =====================================
                 GUEST COUNT
            ====================================== --}}

            <div class="rsvp-field mt-8">

                <label
                    for="guest_count"
                    class="text-[10px] font-medium tracking-[0.25em] text-neutral-600"
                >
                    JUMLAH TAMU
                </label>


                <select
                    id="guest_count"
                    name="guest_count"
                    required
                    class="mt-3 w-full cursor-pointer appearance-none rounded-2xl border border-neutral-200 bg-white px-5 py-4 text-sm text-neutral-800 outline-none transition duration-300 focus:border-neutral-500 focus:ring-2 focus:ring-neutral-200/60"
                >

                    @for ($i = 1; $i <= 10; $i++)

                        <option
                            value="{{ $i }}"
                            {{ old('guest_count', 1) == $i ? 'selected' : '' }}
                        >
                            {{ $i }} {{ $i === 1 ? 'orang' : 'orang' }}
                        </option>

                    @endfor

                </select>

            </div>


            {{-- =====================================
                 MESSAGE
            ====================================== --}}

            <div class="rsvp-field mt-8">

                <label
                    for="message"
                    class="text-[10px] font-medium tracking-[0.25em] text-neutral-600"
                >
                    UCAPAN
                </label>


                <textarea
                    id="message"
                    name="message"
                    rows="5"
                    maxlength="500"
                    placeholder="Tuliskan ucapan dan doa untuk kedua mempelai..."
                    class="mt-3 w-full resize-none rounded-2xl border border-neutral-200 bg-white px-5 py-4 text-sm leading-7 text-neutral-800 outline-none transition duration-300 placeholder:text-neutral-400 focus:border-neutral-500 focus:ring-2 focus:ring-neutral-200/60"
                >{{ old('message') }}</textarea>


                <div
                    class="mt-2 flex justify-end"
                >

                    <span
                        class="text-[9px] tracking-[0.1em] text-neutral-400"
                    >
                        MAKS. 500 KARAKTER
                    </span>

                </div>

            </div>


            {{-- =====================================
                 SUBMIT
            ====================================== --}}

            <button
                type="submit"
                class="rsvp-submit group mt-8 flex w-full items-center justify-center gap-3 rounded-full bg-neutral-900 px-6 py-4 text-[10px] font-medium tracking-[0.3em] text-white transition-all duration-500 hover:-translate-y-1 hover:bg-neutral-700 hover:shadow-xl active:translate-y-0"
            >

                <span>
                    KIRIM RSVP
                </span>

                <span
                    class="text-sm transition-transform duration-500 group-hover:translate-x-1"
                >
                    →
                </span>

            </button>


        </form>


        {{-- =========================================
             BOTTOM ORNAMENT
        ========================================== --}}

        <div
            class="rsvp-bottom mt-14 text-center"
        >

            <div
                class="mx-auto flex items-center justify-center gap-4"
            >

                <span class="h-px w-12 bg-neutral-300"></span>

                <span class="text-lg text-neutral-400">
                    ♡
                </span>

                <span class="h-px w-12 bg-neutral-300"></span>

            </div>


            <p
                class="mt-4 text-[9px] tracking-[0.3em] text-neutral-400"
            >
                TERIMA KASIH ATAS DOA DAN KEHADIRANNYA
            </p>

        </div>


    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.rsvp-section {
    isolation: isolate;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.rsvp-orb-one {

    animation:
        rsvpOrbOne
        13s
        ease-in-out
        infinite
        alternate;

}


.rsvp-orb-two {

    animation:
        rsvpOrbTwo
        15s
        ease-in-out
        infinite
        alternate;

}


@keyframes rsvpOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(35px, 25px, 0)
            scale(1.08);

    }

}


@keyframes rsvpOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-35px, -25px, 0)
            scale(1.08);

    }

}


/* =========================================================
   HEADER
========================================================= */

.rsvp-header {

    opacity: 0;

    transform:
        translateY(25px);

    animation:
        rsvpHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        .1s
        forwards;

}


@keyframes rsvpHeaderIn {

    from {

        opacity: 0;

        transform:
            translateY(25px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   FORM
========================================================= */

.rsvp-field {

    opacity: 0;

    transform:
        translateY(20px);

    animation:
        rsvpFieldIn
        .8s
        cubic-bezier(.22,1,.36,1)
        .3s
        forwards;

}


@keyframes rsvpFieldIn {

    from {

        opacity: 0;

        transform:
            translateY(20px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   ATTENDANCE OPTION
========================================================= */

.attendance-option {

    display:
        block;

    cursor:
        pointer;

}


.attendance-card {

    display:
        flex;

    align-items:
        center;

    gap:
        .75rem;

    border:
        1px solid rgb(229 229 229);

    border-radius:
        1rem;

    background:
        rgba(255,255,255,.65);

    padding:
        1rem;

    transition:
        all .35s ease;

}


.attendance-card:hover {

    transform:
        translateY(-2px);

    background:
        rgba(255,255,255,.9);

    box-shadow:
        0 8px 20px rgba(0,0,0,.04);

}


/* Selected */

.attendance-option input:checked + .attendance-card {

    border-color:
        rgb(64 64 64);

    background:
        rgba(255,255,255,.95);

    box-shadow:
        0 8px 25px rgba(0,0,0,.06);

}


/* =========================================================
   ATTENDANCE ICON
========================================================= */

.attendance-icon {

    display:
        flex;

    height:
        38px;

    width:
        38px;

    flex-shrink:
        0;

    align-items:
        center;

    justify-content:
        center;

    border:
        1px solid rgb(229 229 229);

    border-radius:
        9999px;

    background:
        rgb(250 250 250);

    font-size:
        14px;

    color:
        rgb(115 115 115);

    transition:
        all .35s ease;

}


.attendance-option input:checked + .attendance-card .attendance-icon {

    border-color:
        rgb(64 64 64);

    background:
        rgb(38 38 38);

    color:
        white;

}


/* =========================================================
   CHECK
========================================================= */

.attendance-check {

    display:
        flex;

    height:
        20px;

    width:
        20px;

    flex-shrink:
        0;

    align-items:
        center;

    justify-content:
        center;

    border:
        1px solid rgb(212 212 212);

    border-radius:
        9999px;

    font-size:
        9px;

    color:
        transparent;

    transition:
        all .35s ease;

}


.attendance-option input:checked + .attendance-card .attendance-check {

    border-color:
        rgb(38 38 38);

    background:
        rgb(38 38 38);

    color:
        white;

}


/* =========================================================
   SUBMIT
========================================================= */

.rsvp-submit {

    box-shadow:
        0 8px 25px rgba(0,0,0,.08);

}


.rsvp-submit:hover {

    box-shadow:
        0 15px 35px rgba(0,0,0,.14);

}


/* =========================================================
   BOTTOM
========================================================= */

.rsvp-bottom {

    opacity: 0;

    animation:
        rsvpBottomIn
        1s
        ease-out
        1s
        forwards;

}


@keyframes rsvpBottomIn {

    from {

        opacity: 0;

        transform:
            translateY(15px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   ERROR
========================================================= */

.rsvp-error {

    animation:
        rsvpErrorIn
        .5s
        ease-out;

}


@keyframes rsvpErrorIn {

    from {

        opacity: 0;

        transform:
            translateY(-10px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   SUCCESS POPUP
========================================================= */

.rsvp-popup {

    animation:
        rsvpPopupIn
        .35s
        ease-out;

}


.rsvp-popup-box {

    animation:
        rsvpPopupBoxIn
        .55s
        cubic-bezier(.22,1,.36,1);

}


.rsvp-success-icon {

    animation:
        rsvpSuccessIcon
        .6s
        cubic-bezier(.22,1,.36,1);

}


@keyframes rsvpPopupIn {

    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }

}


@keyframes rsvpPopupBoxIn {

    from {

        opacity: 0;

        transform:
            translateY(25px)
            scale(.95);

    }

    to {

        opacity: 1;

        transform:
            translateY(0)
            scale(1);

    }

}


@keyframes rsvpSuccessIcon {

    from {

        opacity: 0;

        transform:
            scale(.5)
            rotate(-10deg);

    }

    to {

        opacity: 1;

        transform:
            scale(1)
            rotate(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .rsvp-section {

        padding-top:
            5rem;

        padding-bottom:
            5rem;

    }

    .attendance-card {

        padding:
            .9rem;

    }

    .attendance-icon {

        height:
            36px;

        width:
            36px;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .rsvp-orb-one,
    .rsvp-orb-two,
    .rsvp-header,
    .rsvp-field,
    .rsvp-bottom,
    .rsvp-error,
    .rsvp-popup,
    .rsvp-popup-box,
    .rsvp-success-icon {

        animation:
            none !important;

        transition:
            none !important;

        opacity: 1;

        transform: none;

    }

}

</style>