<section
    id="story"
    class="story-section relative overflow-hidden bg-[#eeeeec] px-6 py-24 sm:py-28"
>

    {{-- =========================================
         DECORATIVE BACKGROUND
    ========================================== --}}

    <div
        class="story-orb-one absolute -left-40 top-20 h-80 w-80 rounded-full bg-white/60 blur-3xl"
    ></div>

    <div
        class="story-orb-two absolute -bottom-40 -right-40 h-80 w-80 rounded-full bg-white/60 blur-3xl"
    ></div>


    {{-- =========================================
         MAIN CONTENT
    ========================================== --}}

    <div class="relative z-10 mx-auto max-w-4xl">


        {{-- =========================================
             HEADER
        ========================================== --}}

        <div class="story-header mb-20 text-center">

            <p
                class="text-[10px] font-medium tracking-[0.45em] text-neutral-500"
            >
                OUR STORY
            </p>


            {{-- Ornament --}}

            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span
                    class="h-px w-10 bg-neutral-300"
                ></span>

                <span
                    class="text-sm text-neutral-400"
                >
                    ❦
                </span>

                <span
                    class="h-px w-10 bg-neutral-300"
                ></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Perjalanan Kami
            </h2>


            <p
                class="mx-auto mt-5 max-w-lg text-sm leading-7 text-neutral-500"
            >
                Setiap pertemuan memiliki cerita, dan setiap cerita
                membawa kami menuju hari yang istimewa ini.
            </p>

        </div>


        {{-- =========================================
             TIMELINE
        ========================================== --}}

        <div class="relative">


            {{-- Main vertical line --}}

            <div
                class="story-line absolute left-[7px] top-0 h-full w-px bg-gradient-to-b from-transparent via-neutral-300 to-transparent sm:left-1/2 sm:-translate-x-1/2"
            ></div>


            {{-- =========================================
                 STORY 1
            ========================================== --}}

            <div
                class="story-item group relative mb-20 pl-10 sm:grid sm:grid-cols-2 sm:gap-16 sm:pl-0"
                style="--story-delay: .15s;"
            >

                {{-- Left --}}

                <div
                    class="story-year sm:text-right"
                >

                    <p
                        class="text-4xl font-light tracking-wide text-neutral-900 transition duration-500 group-hover:tracking-wider sm:text-5xl"
                    >
                        2019
                    </p>

                    <p
                        class="mt-3 text-[9px] font-medium tracking-[0.3em] text-neutral-500"
                    >
                        PERTAMA BERTEMU
                    </p>

                </div>


                {{-- Right --}}

                <div class="story-content mt-5 sm:mt-0">

                    <div
                        class="rounded-2xl border border-neutral-200/70 bg-white/40 p-5 transition duration-500 group-hover:-translate-y-1 group-hover:bg-white/65 group-hover:shadow-sm sm:p-6"
                    >

                        <p
                            class="text-sm leading-8 text-neutral-600"
                        >
                            Sebuah pertemuan sederhana menjadi awal dari
                            cerita yang tidak pernah kami bayangkan sebelumnya.
                        </p>

                    </div>

                </div>


                {{-- Timeline dot --}}

                <span
                    class="story-dot absolute left-[2px] top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-[#eeeeec] bg-neutral-700 sm:left-1/2 sm:-translate-x-1/2"
                >
                    <span
                        class="story-dot-ring absolute h-6 w-6 rounded-full border border-neutral-300"
                    ></span>
                </span>

            </div>


            {{-- =========================================
                 STORY 2
            ========================================== --}}

            <div
                class="story-item group relative mb-20 pl-10 sm:grid sm:grid-cols-2 sm:gap-16 sm:pl-0"
                style="--story-delay: .3s;"
            >

                {{-- Left / Mobile description --}}

                <div
                    class="order-2 mt-5 sm:mt-0"
                >

                    <div
                        class="rounded-2xl border border-neutral-200/70 bg-white/40 p-5 transition duration-500 group-hover:-translate-y-1 group-hover:bg-white/65 group-hover:shadow-sm sm:p-6"
                    >

                        <p
                            class="text-sm leading-8 text-neutral-600"
                        >
                            Waktu berjalan dan membuat kami semakin mengenal
                            satu sama lain, berbagi cerita, tawa, dan impian.
                        </p>

                    </div>

                </div>


                {{-- Right / Mobile year --}}

                <div
                    class="order-1 sm:text-right"
                >

                    <p
                        class="text-4xl font-light tracking-wide text-neutral-900 transition duration-500 group-hover:tracking-wider sm:text-5xl"
                    >
                        2021
                    </p>

                    <p
                        class="mt-3 text-[9px] font-medium tracking-[0.3em] text-neutral-500"
                    >
                        MENJALIN HUBUNGAN
                    </p>

                </div>


                {{-- Timeline dot --}}

                <span
                    class="story-dot absolute left-[2px] top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-[#eeeeec] bg-neutral-700 sm:left-1/2 sm:-translate-x-1/2"
                >
                    <span
                        class="story-dot-ring absolute h-6 w-6 rounded-full border border-neutral-300"
                    ></span>
                </span>

            </div>


            {{-- =========================================
                 STORY 3
            ========================================== --}}

            <div
                class="story-item group relative mb-20 pl-10 sm:grid sm:grid-cols-2 sm:gap-16 sm:pl-0"
                style="--story-delay: .45s;"
            >

                {{-- Left --}}

                <div
                    class="story-year sm:text-right"
                >

                    <p
                        class="text-4xl font-light tracking-wide text-neutral-900 transition duration-500 group-hover:tracking-wider sm:text-5xl"
                    >
                        2025
                    </p>

                    <p
                        class="mt-3 text-[9px] font-medium tracking-[0.3em] text-neutral-500"
                    >
                        LAMARAN
                    </p>

                </div>


                {{-- Right --}}

                <div class="story-content mt-5 sm:mt-0">

                    <div
                        class="rounded-2xl border border-neutral-200/70 bg-white/40 p-5 transition duration-500 group-hover:-translate-y-1 group-hover:bg-white/65 group-hover:shadow-sm sm:p-6"
                    >

                        <p
                            class="text-sm leading-8 text-neutral-600"
                        >
                            Dengan keyakinan dan doa, kami memutuskan untuk
                            melangkah ke tahap berikutnya dan mengikat janji.
                        </p>

                    </div>

                </div>


                {{-- Timeline dot --}}

                <span
                    class="story-dot absolute left-[2px] top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-[#eeeeec] bg-neutral-700 sm:left-1/2 sm:-translate-x-1/2"
                >
                    <span
                        class="story-dot-ring absolute h-6 w-6 rounded-full border border-neutral-300"
                    ></span>
                </span>

            </div>


            {{-- =========================================
                 STORY 4
            ========================================== --}}

            <div
                class="story-item group relative pl-10 sm:grid sm:grid-cols-2 sm:gap-16 sm:pl-0"
                style="--story-delay: .6s;"
            >

                {{-- Left / Mobile description --}}

                <div
                    class="order-2 mt-5 sm:mt-0"
                >

                    <div
                        class="rounded-2xl border border-neutral-200/70 bg-white/40 p-5 transition duration-500 group-hover:-translate-y-1 group-hover:bg-white/65 group-hover:shadow-sm sm:p-6"
                    >

                        <p
                            class="text-sm leading-8 text-neutral-600"
                        >
                            Kini kami siap memulai babak baru dalam kehidupan,
                            bersama dalam satu ikatan pernikahan.
                        </p>

                    </div>

                </div>


                {{-- Right / Mobile year --}}

                <div
                    class="order-1 sm:text-right"
                >

                    <p
                        class="text-4xl font-light tracking-wide text-neutral-900 transition duration-500 group-hover:tracking-wider sm:text-5xl"
                    >
                        2026
                    </p>

                    <p
                        class="mt-3 text-[9px] font-medium tracking-[0.3em] text-neutral-500"
                    >
                        MENUJU PERNIKAHAN
                    </p>

                </div>


                {{-- Timeline dot --}}

                <span
                    class="story-dot absolute left-[2px] top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-[#eeeeec] bg-neutral-900 sm:left-1/2 sm:-translate-x-1/2"
                >
                    <span
                        class="story-dot-ring absolute h-7 w-7 rounded-full border border-neutral-400"
                    ></span>
                </span>

            </div>


        </div>


        {{-- =========================================
             BOTTOM ORNAMENT
        ========================================== --}}

        <div
            class="story-bottom mt-20 text-center"
        >

            <div
                class="mx-auto flex items-center justify-center gap-4"
            >

                <span class="h-px w-12 bg-neutral-300"></span>

                <span class="text-xl font-light text-neutral-400">
                    ♡
                </span>

                <span class="h-px w-12 bg-neutral-300"></span>

            </div>

            <p
                class="mt-5 text-[9px] tracking-[0.3em] text-neutral-400"
            >
                AND THE STORY CONTINUES
            </p>

        </div>

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.story-section {
    isolation: isolate;
}


/* =========================================================
   BACKGROUND ORBS
========================================================= */

.story-orb-one {
    animation:
        storyOrbOne
        13s
        ease-in-out
        infinite
        alternate;
}

.story-orb-two {
    animation:
        storyOrbTwo
        15s
        ease-in-out
        infinite
        alternate;
}


@keyframes storyOrbOne {

    from {
        transform:
            translate3d(0, 0, 0)
            scale(1);
    }

    to {
        transform:
            translate3d(40px, 25px, 0)
            scale(1.08);
    }

}


@keyframes storyOrbTwo {

    from {
        transform:
            translate3d(0, 0, 0)
            scale(1);
    }

    to {
        transform:
            translate3d(-35px, -30px, 0)
            scale(1.08);
    }

}


/* =========================================================
   HEADER
========================================================= */

.story-header {

    opacity: 0;

    transform:
        translateY(25px);

    animation:
        storyHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        .1s
        forwards;

}


@keyframes storyHeaderIn {

    from {

        opacity: 0;

        transform:
            translateY(25px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   TIMELINE LINE
========================================================= */

.story-line {

    opacity: 0;

    animation:
        storyLineIn
        1.8s
        ease-out
        .4s
        forwards;

}


@keyframes storyLineIn {

    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }

}


/* =========================================================
   STORY ITEMS
========================================================= */

.story-item {

    opacity: 0;

    transform:
        translateY(35px);

    animation:
        storyItemIn
        1s
        cubic-bezier(.22,1,.36,1)
        var(--story-delay)
        forwards;

}


@keyframes storyItemIn {

    from {

        opacity: 0;

        transform:
            translateY(35px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   DOT
========================================================= */

.story-dot {

    z-index: 5;

    box-shadow:
        0 0 0 4px rgba(238,238,236,.9);

}


.story-dot-ring {

    opacity: .45;

    animation:
        storyDotPulse
        3s
        ease-in-out
        infinite;

}


@keyframes storyDotPulse {

    0%,
    100% {

        transform:
            scale(.85);

        opacity: .25;

    }

    50% {

        transform:
            scale(1.2);

        opacity: .65;

    }

}


/* =========================================================
   BOTTOM
========================================================= */

.story-bottom {

    opacity: 0;

    animation:
        storyBottomIn
        1s
        ease-out
        1s
        forwards;

}


@keyframes storyBottomIn {

    from {

        opacity: 0;

        transform:
            translateY(15px);

    }

    to {

        opacity: 1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .story-section {

        padding-top:
            5rem;

        padding-bottom:
            5rem;

    }

    .story-item {

        padding-left:
            2.5rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .story-orb-one,
    .story-orb-two,
    .story-header,
    .story-line,
    .story-item,
    .story-dot-ring,
    .story-bottom {

        animation:
            none !important;

        transition:
            none !important;

        opacity: 1;

        transform: none;

    }

}

</style>