<section
    id="wishes"
    class="wishes-section relative overflow-hidden bg-[#f3f3f1] px-6 py-24 sm:py-28"
>

    {{-- =========================================
         DECORATIVE BACKGROUND
    ========================================== --}}

    <div
        class="wishes-orb-one absolute -left-40 top-10 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>

    <div
        class="wishes-orb-two absolute -bottom-40 -right-40 h-80 w-80 rounded-full bg-white/70 blur-3xl"
    ></div>


    {{-- =========================================
         MAIN CONTENT
    ========================================== --}}

    <div class="relative z-10 mx-auto max-w-3xl">


        {{-- =========================================
             HEADER
        ========================================== --}}

        <div class="wishes-header mb-12 text-center">

            <p
                class="text-[10px] font-medium tracking-[0.45em] text-neutral-500"
            >
                WISHES
            </p>


            <div
                class="mx-auto mt-5 flex items-center justify-center gap-3"
            >

                <span class="h-px w-10 bg-neutral-300"></span>

                <span class="text-sm text-neutral-400">
                    ❦
                </span>

                <span class="h-px w-10 bg-neutral-300"></span>

            </div>


            <h2
                class="mt-5 text-3xl font-light tracking-wide text-neutral-900 sm:text-4xl"
            >
                Ucapan & Doa
            </h2>


            <p
                class="mx-auto mt-5 max-w-md text-sm leading-7 text-neutral-500"
            >
                Doa dan ucapan dari keluarga serta sahabat
                menjadi bagian indah dalam perjalanan kami.
            </p>

        </div>


        {{-- =========================================
             WISHES LIST
        ========================================== --}}

        <div class="space-y-5">

            @forelse (
                $wedding->rsvps
                    ->whereNotNull('message')
                    ->where('message', '!=', '')
                    ->sortByDesc('created_at')
                as $rsvp
            )

                <div
                    class="wish-card group relative overflow-hidden rounded-[1.75rem] border border-neutral-200/80 bg-white/75 p-6 shadow-sm sm:p-7"
                    style="--wish-delay: {{ $loop->index * 0.1 + 0.15 }}s;"
                >

                    {{-- Decorative quote --}}

                    <div
                        class="absolute -right-2 -top-5 select-none text-[90px] font-serif leading-none text-neutral-200/60"
                    >
                        ”
                    </div>


                    {{-- Quote icon --}}

                    <div
                        class="relative z-10 mb-4 flex h-9 w-9 items-center justify-center rounded-full border border-neutral-200 bg-white text-sm text-neutral-400"
                    >
                        “
                    </div>


                    {{-- Message --}}

                    <p
                        class="relative z-10 text-sm leading-8 text-neutral-700"
                    >
                        “{{ $rsvp->message }}”
                    </p>


                    {{-- Divider --}}

                    <div
                        class="my-5 h-px w-full bg-neutral-200/80"
                    ></div>


                    {{-- Bottom information --}}

                    <div
                        class="relative z-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
                    >

                        {{-- Name --}}

                        <div>

                            <p
                                class="text-sm font-medium text-neutral-900"
                            >
                                {{ $rsvp->name }}
                            </p>


                            @if ($rsvp->created_at)

                                <p
                                    class="mt-1 text-[9px] tracking-[0.15em] text-neutral-400"
                                >
                                    {{ $rsvp->created_at->format('d M Y') }}
                                </p>

                            @endif

                        </div>


                        {{-- Attendance --}}

                        <div>

                            @if ($rsvp->attendance === 'hadir')

                                <span
                                    class="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-neutral-50 px-4 py-2 text-[9px] font-medium tracking-[0.15em] text-neutral-600"
                                >
                                    <span
                                        class="h-1.5 w-1.5 rounded-full bg-neutral-700"
                                    ></span>

                                    AKAN HADIR
                                </span>

                            @elseif ($rsvp->attendance === 'tidak_hadir')

                                <span
                                    class="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-neutral-50 px-4 py-2 text-[9px] font-medium tracking-[0.15em] text-neutral-500"
                                >
                                    <span
                                        class="h-1.5 w-1.5 rounded-full bg-neutral-400"
                                    ></span>

                                    TIDAK HADIR
                                </span>

                            @else

                                <span
                                    class="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-neutral-50 px-4 py-2 text-[9px] font-medium tracking-[0.15em] text-neutral-500"
                                >
                                    <span
                                        class="h-1.5 w-1.5 rounded-full bg-neutral-400"
                                    ></span>

                                    MASIH RAGU
                                </span>

                            @endif

                        </div>

                    </div>

                </div>

            @empty

                {{-- =====================================
                     EMPTY STATE
                ====================================== --}}

                <div
                    class="wish-empty rounded-[1.75rem] border border-dashed border-neutral-300 bg-white/40 px-6 py-14 text-center"
                >

                    <div
                        class="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-neutral-200 bg-white"
                    >
                        <span
                            class="text-xl font-light text-neutral-400"
                        >
                            ♡
                        </span>
                    </div>


                    <p
                        class="mt-5 text-sm text-neutral-500"
                    >
                        Belum ada ucapan.
                    </p>


                    <p
                        class="mt-2 text-xs leading-6 text-neutral-400"
                    >
                        Jadilah yang pertama memberikan doa
                        untuk kedua mempelai.
                    </p>

                </div>

            @endforelse

        </div>


        {{-- =========================================
             BOTTOM ORNAMENT
        ========================================== --}}

        <div
            class="wishes-bottom mt-14 text-center"
        >

            <div
                class="mx-auto flex items-center justify-center gap-4"
            >

                <span class="h-px w-12 bg-neutral-300"></span>

                <span class="text-lg text-neutral-400">
                    ♡
                </span>

                <span class="h-px w-12 bg-neutral-300"></span>

            </div>


            <p
                class="mt-4 text-[9px] tracking-[0.3em] text-neutral-400"
            >
                WITH LOVE
            </p>

        </div>

    </div>

</section>


<style>

/* =========================================================
   SECTION
========================================================= */

.wishes-section {
    isolation: isolate;
}


/* =========================================================
   BACKGROUND
========================================================= */

.wishes-orb-one {

    animation:
        wishesOrbOne
        13s
        ease-in-out
        infinite
        alternate;

}


.wishes-orb-two {

    animation:
        wishesOrbTwo
        15s
        ease-in-out
        infinite
        alternate;

}


@keyframes wishesOrbOne {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(35px, 25px, 0)
            scale(1.08);

    }

}


@keyframes wishesOrbTwo {

    from {

        transform:
            translate3d(0, 0, 0)
            scale(1);

    }

    to {

        transform:
            translate3d(-35px, -25px, 0)
            scale(1.08);

    }

}


/* =========================================================
   HEADER
========================================================= */

.wishes-header {

    opacity:
        0;

    transform:
        translateY(25px);

    animation:
        wishesHeaderIn
        1s
        cubic-bezier(.22,1,.36,1)
        .1s
        forwards;

}


@keyframes wishesHeaderIn {

    from {

        opacity:
            0;

        transform:
            translateY(25px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   WISH CARD
========================================================= */

.wish-card {

    opacity:
        0;

    transform:
        translateY(25px)
        scale(.98);

    animation:
        wishCardIn
        .8s
        cubic-bezier(.22,1,.36,1)
        var(--wish-delay)
        forwards;

    transition:
        transform .5s ease,
        box-shadow .5s ease,
        background-color .5s ease;

}


.wish-card:hover {

    transform:
        translateY(-4px);

    background-color:
        rgba(255,255,255,.9);

    box-shadow:
        0 15px 35px rgba(0,0,0,.06);

}


@keyframes wishCardIn {

    from {

        opacity:
            0;

        transform:
            translateY(25px)
            scale(.98);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0)
            scale(1);

    }

}


/* =========================================================
   EMPTY
========================================================= */

.wish-empty {

    animation:
        wishEmptyIn
        .8s
        ease-out;

}


@keyframes wishEmptyIn {

    from {

        opacity:
            0;

        transform:
            translateY(20px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   BOTTOM
========================================================= */

.wishes-bottom {

    opacity:
        0;

    animation:
        wishesBottomIn
        1s
        ease-out
        1s
        forwards;

}


@keyframes wishesBottomIn {

    from {

        opacity:
            0;

        transform:
            translateY(15px);

    }

    to {

        opacity:
            1;

        transform:
            translateY(0);

    }

}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 640px) {

    .wishes-section {

        padding-top:
            5rem;

        padding-bottom:
            5rem;

    }

    .wish-card {

        border-radius:
            1.5rem;

    }

}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {

    .wishes-orb-one,
    .wishes-orb-two,
    .wishes-header,
    .wish-card,
    .wish-empty,
    .wishes-bottom {

        animation:
            none !important;

        transition:
            none !important;

        opacity:
            1;

        transform:
            none;

    }

}

</style>